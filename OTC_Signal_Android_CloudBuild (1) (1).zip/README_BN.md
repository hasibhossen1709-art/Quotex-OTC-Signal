# Quotex OTC Signal Assistant — Android project

## কী আছে
- বাংলা Android WebView অ্যাপ
- OTC pair selector
- হাতে দেওয়া closing price থেকে EMA 5/10 এবং RSI-ভিত্তিক UP / DOWN / WAIT বিশ্লেষণ
- সম্পূর্ণ offline; কোনো ভুয়া live quote বা fabricated signal নেই

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই প্রজেক্ট Quotex-এর সঙ্গে সংযুক্ত নয় এবং Quotex OTC-এর অনুমোদিত live market feed/API এতে নেই। তাই এটি নিজে থেকে live price পড়তে বা live signal দিতে পারে না। Quotex-এর অনুমোদিত data access/API না পাওয়া পর্যন্ত closing price হাতে দিতে হবে। স্কোরটি win probability নয় এবং ৯৯% accuracy দাবি করে না।

## APK বানানোর নিয়ম
1. Android Studio ইনস্টল করুন।
2. `QuotexOTCSignalApp` ফোল্ডারটি Android Studio-তে Open করুন।
3. Gradle sync শেষ হতে দিন (প্রথমবার internet লাগবে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যাবে।

Min SDK: Android 6.0 (API 23), Target SDK: 35.
